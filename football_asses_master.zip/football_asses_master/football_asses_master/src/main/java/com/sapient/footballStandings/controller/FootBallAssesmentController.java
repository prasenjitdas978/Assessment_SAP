package com.sapient.footballStandings.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sapient.footballStandings.service.FootBallAssesmentService;
import com.sapient.footballStandings.service.impl.FootBallAssesmentServiceImpl;

@RestController
@RequestMapping("/api/v1")
public class FootBallAssesmentController {
	@Autowired
	FootBallAssesmentService service;
	 Logger logger = LoggerFactory.getLogger(FootBallAssesmentServiceImpl.class);

	@GetMapping("/welcome")
	public String getIndex() {
		return "Welcome to All";
	}
	@GetMapping("/getCountries")
	public String getCountriesDetails(@RequestParam(name="action") String action, @RequestParam(name="APIkey") String apiKey) throws Exception {
		try {
			return service.getCountries(action, apiKey);
			
			
		} catch (Exception e) {
			throw e;
		}
		
	}
	
}

package com.sapient.footballStandings.service;

public interface FootBallAssesmentService {
	public String getCountries(String action, String apiKey)throws Exception;

}
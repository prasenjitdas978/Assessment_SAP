package com.sapient.footballStandings.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sapient.footballStandings.service.FootBallAssesmentService;
@Service
public class FootBallAssesmentServiceImpl implements FootBallAssesmentService {
	@Value("${url}")
	String apiUrl;
	   Logger logger = LoggerFactory.getLogger(FootBallAssesmentServiceImpl.class);
	@Override
	public String getCountries(String action, String apiKey) throws Exception{
		String url = apiUrl + "?action=" +action+"&APIkey="+apiKey;		
		logger.debug("URL IS "+url);
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        HttpEntity entity = new HttpEntity<>(requestHeaders);
        logger.debug("URL IS "+url);
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
		logger.debug("API>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+response);
		if(response.getStatusCode()!=HttpStatus.OK) {
			
			throw new Exception(response.getBody());
			
		}
		return response.getBody();
	}

}
